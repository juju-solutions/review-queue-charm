from base import (
    UnitTestBase,
)


class DBTest(UnitTestBase):
    def test_something(self):
        pass
