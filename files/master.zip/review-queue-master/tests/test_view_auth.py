from base import (
    IntegrationTestBase,
)


class AuthIntegrationTest(IntegrationTestBase):
    def test_login_existing_user(self):
        pass

    def test_login_new_user(self):
        pass

    def test_login_failure(self):
        pass

    def test_logout(self):
        pass
